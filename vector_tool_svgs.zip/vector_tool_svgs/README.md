# Vector Tool Icons

Nine individual SVG icons with a shared `24 × 24` viewBox and `1.8` stroke width.

Files: `select.svg`, `rectangle.svg`, `ellipse.svg`, `star.svg`, `pen.svg`, `lasso.svg`, `paint.svg`, `ruler.svg`, `pan.svg`.

- No background; transparent by default.
- `stroke="currentColor"` lets the application control icon color.
- Rounded stroke caps and joins.
- Intended for consistent sizing in a vector/normal-map editor toolbar.
